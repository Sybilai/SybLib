#include "Bot.h"
using namespace boom;


Bot::Bot(std::string name) : 
	IBot(name) 
{ }

// -------------------------------
// This will be called every frame
// -------------------------------
// Possible commands to authority:
// WorldInterface::PlantBomb();
// WorldInterface::GoTo(x, y);
// -------------------------------
void Bot::Update()
{

}